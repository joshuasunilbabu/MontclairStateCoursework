<?php
// comments.php - Comments Page
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$comment = $_POST['comment'] ?? '';
$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($name) && empty($email) && empty($comment)) {
        $message = "You must enter at least one field.";
    } elseif (empty($comment)) {
        $message = "Please enter a comment.";
    } else {
        $greet = !empty($name) ? $name : (!empty($email) ? $email : "Guest");
        $message = "Dear $greet, thank you for your comment!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Joshua's Resort - Comments</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include('navbar.php'); ?>
<div class="container mt-5">
  <h2 class="text-center">Leave a Comment</h2>
  <form method="POST" class="p-4 bg-light border rounded">
    <input type="text" name="name" class="form-control mb-3" placeholder="Name">
    <input type="email" name="email" class="form-control mb-3" placeholder="Email">
    <textarea name="comment" class="form-control mb-3" placeholder="Your Comment"></textarea>
    <button class="btn btn-primary w-100">Submit</button>
  </form>
  <?php if ($message): ?>
    <div class="alert alert-info mt-3 text-center"><?php echo $message; ?></div>
  <?php endif; ?>
</div>
</body>
</html>

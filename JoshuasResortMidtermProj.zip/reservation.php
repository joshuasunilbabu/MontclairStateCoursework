<?php
// reservation.php - Reservation Form
$taxRate = 0.07;
$totalCharge = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $room = $_POST['roomType'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $days = (strtotime($checkout) - strtotime($checkin)) / (60*60*24);
    if ($days == 0) $days = 1;
    $rates = ['King'=>200, 'Queen'=>150, 'Suite'=>300];
    $totalCharge = ($rates[$room] * $days) * (1 + $taxRate);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Joshua's Resort - Reservation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('navbar.php'); ?>
<div class="container mt-4">
  <h2 class="text-center">Make a Reservation</h2>
  <form method="POST" class="p-4 border rounded bg-light">
    <div class="row g-3">
      <div class="col-md-6"><input type="text" name="firstName" class="form-control" placeholder="First Name" required autofocus></div>
      <div class="col-md-6"><input type="text" name="lastName" class="form-control" placeholder="Last Name" required></div>
      <div class="col-12"><input type="text" name="address" class="form-control" placeholder="Address" required></div>
      <div class="col-md-6"><input type="date" name="checkin" class="form-control" required></div>
      <div class="col-md-6"><input type="date" name="checkout" class="form-control" required></div>
      <div class="col-md-6">
        <select name="roomType" class="form-select" required>
          <option value="King">King</option>
          <option value="Queen">Queen</option>
          <option value="Suite">Suite</option>
        </select>
      </div>
      <div class="col-md-6"><input type="number" name="people" class="form-control" placeholder="Number of People" required></div>
      <div class="col-md-6"><input type="text" name="phone" class="form-control" placeholder="(123) 456-7890" required></div>
      <div class="col-md-6"><input type="email" name="email" class="form-control" placeholder="Email" required></div>
      <div class="col-md-6">
        <select name="payment" class="form-select" required>
          <option value="MC">MasterCard</option>
          <option value="VISA">VISA</option>
          <option value="AMEX">AMEX</option>
          <option value="Discover">Discover</option>
        </select>
      </div>
      <div class="col-md-6"><input type="text" name="card" maxlength="19" class="form-control" placeholder="1234 5678 9012 3456" required></div>
      <div class="col-12"><textarea name="requests" class="form-control" placeholder="Special Requests (optional)"></textarea></div>
      <div class="col-12 text-center"><button class="btn btn-primary">Submit</button></div>
    </div>
  </form>
  <?php if ($totalCharge): ?>
    <div class="alert alert-success mt-4 text-center">
      <strong>Total charge: $<?php echo number_format($totalCharge, 2); ?></strong>
    </div>
  <?php endif; ?>
</div>
</body>
</html>

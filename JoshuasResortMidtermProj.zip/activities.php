<?php
// activities.php - Activities Page
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Joshua's Resort - Activities</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('navbar.php'); ?>
<div class="container text-center mt-5">
  <h2>Activities at Joshua's Resort</h2>
  <div class="row mt-4">
    <div class="col-sm-6 col-lg-3 mb-4"><img src="images/pool.jpg" class="img-fluid rounded shadow activity-img" alt="Pool"></div>
    <div class="col-sm-6 col-lg-3 mb-4"><img src="images/hiking.jpg" class="img-fluid rounded shadow activity-img" alt="Hiking"></div>
    <div class="col-sm-6 col-lg-3 mb-4"><img src="images/biking.jpg" class="img-fluid rounded shadow activity-img" alt="Biking"></div>
  </div>
</div>
</body>
</html>

<?php
// yurts.php - Yurts Page
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Joshua's Resort - Yurts</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('navbar.php'); ?>
<div class="container mt-5 text-center">
  <h2>Our Luxury Yurts</h2>
  <img src="images/yurt.jpg" class="img-fluid rounded shadow mt-3" alt="Yurt">
  <p class="mt-3">Enjoy nature with all the comforts of a luxury stay in our premium yurts.</p>
</div>
</body>
</html>
